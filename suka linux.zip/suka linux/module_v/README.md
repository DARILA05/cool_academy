# Модуль В — Моделирование и прогнозирование рисков

Готовый конвейер машинного обучения для анализа туристических треков и прогнозирования рисков.

Структура
module_v/
├── config.yaml               # Конфигурация
├── train_pipeline.py         # Обучение модели
├── module_v.ipynb            # Анализ и визуализация
├── labeled_dataset.csv       # Входной датасет (пример)
├── models/                   # Выход: модель и метрики
└── maps/                     # Прогнозные карты


 Зависимости

Установите через pip:
```bash
pip install -r requirements.txt

Требуется Python 3.8+


 Запуск обучения
Bash
python train_pipeline.py \
  --data_path labeled_dataset.csv \
  --model_output_dir models \
  --config config.yaml
После запуска:

Лучшая модель сохраняется в models/best_model.pkl
Метрики — в models/metrics.json
📊 Анализ результатов
Запустите Jupyter:

Bash
jupyter notebook module_v.ipynb
Или конвертируйте в скрипт:

Bash
jupyter nbconvert --to script module_v.ipynb
python module_v.py
 Что делает ноутбук

Анализ модели:


Важность признаков
Матрица ошибок
ROC-кривая


Прогноз временных рядов:


Использует Prophet
Прогноз на 5 лет вперёд по кластерам


Карты рисков:


Генерирует интерактивные карты (maps/*.html)
Цвет — уровень опасности