#!/usr/bin/env python3
# train_pipeline.py — обучение модели рисков

import os
import sys
import argparse
import logging
import json
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from xgboost import XGBClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    classification_report,
)
import joblib
import yaml

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(description="Pipeline обучения классификатора риска")
    parser.add_argument("--data_path", type=str, required=True, help="Путь к CSV-файлу")
    parser.add_argument("--model_output_dir", type=str, default="models", help="Папка для сохранения модели")
    parser.add_argument("--test_size", type=float, default=0.2, help="Доля тестовой выборки")
    parser.add_argument("--retrain", action="store_true", help="Принудительное переобучение")
    parser.add_argument("--incremental", action="store_true", help="Инкрементальное обучение (заглушка)")
    parser.add_argument("--config", type=str, default="config.yaml", help="Путь к конфигу")
    return parser.parse_args()


def load_config(path):
    if not os.path.exists(path):
        logger.error(f"Конфиг не найден: {path}")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_and_preprocess(data_path):
    """Загрузка и предобработка данных"""
    if not os.path.exists(data_path):
        logger.error(f"Файл данных не найден: {data_path}")
        sys.exit(1)

    try:
        df = pd.read_csv(data_path, encoding="utf-8")
        logger.info(f"✅ Загружено {len(df)} строк из {data_path}")

        if "risk_level" not in df.columns:
            logger.error("❌ В данных отсутствует колонка 'risk_level'")
            sys.exit(1)

        df = df.dropna(subset=["risk_level"]).copy()
        df["target"] = (df["risk_level"] == "High").astype(int)

        features = [c for c in df.columns if c not in ["risk_level", "target", "cluster_id", "evacuation_difficulty"]]
        if not features:
            logger.error("❌ Не найдено признаков для обучения")
            sys.exit(1)

        X = df[features].copy()
        y = df["target"]

        # Кодируем категориальные признаки
        cat_cols = X.select_dtypes(include=["object"]).columns.tolist()
        enc = LabelEncoder()
        for col in cat_cols:
            X[col] = enc.fit_transform(X[col].astype(str))

        # Нормализуем числовые
        num_cols = X.select_dtypes(include=[np.number]).columns.tolist()
        scaler = StandardScaler()
        X[num_cols] = scaler.fit_transform(X[num_cols])

        logger.info(f"📊 Признаков: {len(features)}, Объектов: {len(X)}")
        return X, y, scaler, enc

    except Exception as e:
        logger.error(f"Ошибка загрузки данных: {e}")
        sys.exit(1)


def train_models(X_train, y_train, config):
    """Обучение моделей с подбором гиперпараметров"""
    models = {
        "RandomForest": RandomForestClassifier(n_estimators=config["n_estimators"], max_depth=config["max_depth"], random_state=42),
        "XGB": XGBClassifier(use_label_encoder=False, eval_metric="logloss", random_state=42),
        "LogisticRegression": LogisticRegression(solver="lbfgs", max_iter=500, random_state=42),
        "KNeighbors": KNeighborsClassifier(n_neighbors=config["n_neighbors"]),
    }

    param_grids = {
        "RandomForest": {"n_estimators": [100, 150], "max_depth": [6, 8]},
        "XGB": {"n_estimators": [80, 120], "max_depth": [3, 6]},
        "LogisticRegression": {"C": [0.2, 1.0]},
        "KNeighbors": {"n_neighbors": [5, 8, 11]},
    }

    best_model = None
    best_score = 0
    best_name = ""

    scoring = config.get("scoring", "roc_auc")

    for name, model in models.items():
        try:
            clf = GridSearchCV(model, param_grids[name], scoring=scoring, cv=3, n_jobs=-1)
            clf.fit(X_train, y_train)
            if clf.best_score_ > best_score:
                best_score, best_model, best_name = clf.best_score_, clf.best_estimator_, name
            logger.info(f"✅ {name}: {clf.best_score_:.4f} ({scoring})")
        except Exception as e:
            logger.warning(f"⚠️ Ошибка при обучении {name}: {e}")

    logger.info(f"🏆 Лучшая модель: {best_name} с {best_score:.4f}")
    return best_name, best_model


def evaluate_and_save(best_model, X_test, y_test, output_dir):
    """Оценка и сохранение модели"""
    os.makedirs(output_dir, exist_ok=True)

    y_pred = best_model.predict(X_test)
    y_proba = best_model.predict_proba(X_test)[:, 1] if hasattr(best_model, "predict_proba") else y_pred

    metrics = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, y_proba)),
        "classification_report": classification_report(y_test, y_pred, output_dict=True),
    }

    # Сохраняем
    model_path = os.path.join(output_dir, "best_model.pkl")
    joblib.dump(best_model, model_path)
    logger.info(f"💾 Модель сохранена: {model_path}")

    metrics_path = os.path.join(output_dir, "metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=4)
    logger.info(f"📊 Метрики сохранены: {metrics_path}")

    return metrics


def check_data_drift(new_data, reference_data, threshold=0.15, comp_features=None):
    """Простая проверка дрейфа данных по средним"""
    if comp_features is None:
        comp_features = ["elevation", "temperature", "step_frequency"]

    drifted = False
    for feat in comp_features:
        if feat not in new_data.columns or feat not in reference_data.columns:
            continue
        ref_mean = reference_data[feat].mean()
        new_mean = new_data[feat].mean()
        relative_change = abs(new_mean - ref_mean) / (abs(ref_mean) + 1e-6)
        if relative_change > threshold:
            logger.warning(f"⚠️ Дрейф обнаружен в '{feat}': {relative_change:.3f} > {threshold}")
            drifted = True

    logger.info(f"📊 Дрейф данных: {'ДА' if drifted else 'нет'}")
    return drifted


if __name__ == "__main__":
    args = parse_args()
    config = load_config(args.config)

    # Загрузка и предобработка
    X, y, scaler, enc = load_and_preprocess(args.data_path)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=args.test_size, random_state=42)

    # Обучение
    model_config = config["model"]
    best_name, best_model = train_models(X_train, y_train, model_config)

    # Оценка
    metrics = evaluate_and_save(best_model, X_test, y_test, args.model_output_dir)

    # Проверка дрейфа
    drift = check_data_drift(
        X_test, X_train,
        threshold=config["drift"].get("drift_threshold", 0.15),
        comp_features=config["drift"].get("compare_features")
    )

    if drift and not args.retrain:
        logger.warning("РЕКОМЕНДУЕТСЯ полное переобучение модели!")