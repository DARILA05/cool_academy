# config.py — все параметры для гибкой настройки

import os

# Пути к данным
PROVIDED_PATH_1 = os.getenv("PROVIDED_PATH_1", "provided_tracks_1.csv")
PROVIDED_PATH_2 = os.getenv("PROVIDED_PATH_2", "provided_tracks_2.csv")

# Ограничения на чтение больших файлов
PROVIDED_MAX_ROWS = int(os.getenv("PROVIDED_MAX_ROWS", "0"))
PROVIDED_CHUNKSIZE = int(os.getenv("PROVIDED_CHUNKSIZE", "0"))

# Настройки Overpass API
EXTERNAL_API_URL = os.getenv("EXTERNAL_API_URL", "https://overpass-api.de/api/interpreter")
OVERPASS_TIMEOUT = int(os.getenv("OVERPASS_TIMEOUT", "25"))

# Запросы по регионам (bbox: [south, west, north, east])
OVERPASS_QUERIES = [
    {
        "name": "city_trails",
        "bbox": [55.70, 37.50, 55.82, 37.72],
        "region": "Moscow_city",
    },
    {
        "name": "mountain_trails",
        "bbox": [43.50, 39.90, 43.70, 40.10],
        "region": "Caucasus",
    },
]

OVERPASS_MAX_TRACKS_PER_QUERY = int(os.getenv("OVERPASS_MAX_TRACKS_PER_QUERY", "50"))

# Кэширование внешних данных
SAMPLE_PROVIDED_1 = os.getenv("SAMPLE_PROVIDED_1", "sample_provided_tracks_1.csv")
SAMPLE_PROVIDED_2 = os.getenv("SAMPLE_PROVIDED_2", "sample_provided_tracks_2.csv")

# Аугментация
AUGMENT_SHIFT_METERS = 15  # Максимальный сдвиг координат, метров
AUGMENT_ELEV_NOISE = 5     # Шум по высоте (метры)
IMG_BRIGHTNESS = 1.2       # Фактор яркости
IMG_CONTRAST = 1.1         # Фактор контраста
IMG_FLIP_PROB = 0.5        # Вероятность зеркалирования

# Пути (с использованием os.path для совместимости)
DB_PATH = os.path.join(".", "tracks.db")
REPORT_DIR = os.path.join(".", "report")

# Симуляция данных
SIMULATE_DATA = True
SIMULATED_TRACKS_COUNT = 100