Если хотите запускать без Jupyter, выполните:

Bash
jupyter nbconvert --to script module_a.ipy

зависимости
pip install -r requirements.txt