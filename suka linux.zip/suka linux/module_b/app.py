import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import sqlite3
import folium
from streamlit_folium import st_folium
from datetime import datetime
import os
import json
from dotenv import load_dotenv

# Загружаем .env
load_dotenv()

# Настройки страницы
st.set_page_config(
    page_title="Аналитика туристических треков",
    page_icon="🗺️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS для улучшения внешнего вида
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1E3A8A;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #F3F4F6;
        padding: 1rem;
        border-radius: 10px;
        border-left: 5px solid #3B82F6;
    }
    .section-header {
        font-size: 1.8rem;
        color: #1F2937;
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-bottom: 2px solid #E5E7EB;
        padding-bottom: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

st.markdown("<h1 class='main-header'>📊 Аналитическая система туристических треков</h1>", unsafe_allow_html=True)

# Загрузка данных
@st.cache_data(ttl=int(os.getenv("CACHE_TTL", "3600")))
def load_data():
    """Загрузка данных с поддержкой нескольких источников"""
    sources = os.getenv("DATA_SOURCE_PRIORITY", "csv,db").split(",")
    
    # 1. CSV — основной источник
    if "csv" in sources:
        for path_env in ["CSV_PATH_1", "CSV_PATH_2"]:
            path = os.getenv(path_env)
            if path and os.path.exists(path):
                try:
                    df = pd.read_csv(path, encoding='utf-8')
                    st.success(f"✅ Данные загружены из: {path}")
                    return df
                except Exception as e:
                    st.warning(f"⚠️ Не удалось прочитать {path}: {e}")

    # 2. SQLite
    if "db" in sources:
        for db_env in ["DB_PATH", "DB_PATH_FALLBACK"]:
            db_path = os.getenv(db_env)
            if db_path and os.path.exists(db_path):
                try:
                    conn = sqlite3.connect(db_path)
                    df_tracks = pd.read_sql('SELECT * FROM tracks', conn)
                    df_points = pd.read_sql('SELECT * FROM track_points', conn)
                    conn.close()
                    df = pd.merge(df_points, df_tracks, on='track_id', how='left')
                    st.info(f"🔁 Загружены данные из БД: {db_path}")
                    return df
                except Exception as e:
                    st.warning(f"⚠️ Ошибка БД {db_path}: {e}")

    # 3. Генерация демо-данных
    st.warning("⚠️ Созданы демонстрационные данные")
    np.random.seed(42)
    n_points = 500
    df = pd.DataFrame({
        'track_id': [f'track_{i//10}' for i in range(n_points)],
        'date': pd.date_range('2024-01-01', periods=n_points, freq='H').strftime('%Y-%m-%d'),
        'region': np.random.choice(['Москва', 'Кавказ', 'Урал', 'Сибирь'], n_points),
        'lat': 55.75 + np.random.randn(n_points) * 0.1,
        'lon': 37.62 + np.random.randn(n_points) * 0.1,
        'step_frequency': np.random.normal(90, 15, n_points),
        'elevation': np.random.uniform(50, 1000, n_points),
        'temperature': np.random.uniform(-10, 25, n_points),
        'terrain_type': np.random.choice(['горы', 'холмы', 'равнина', 'низменность'], n_points),
        'season': np.random.choice(['зима', 'весна', 'лето', 'осень'], n_points),
        'risk_level': np.random.choice(['High', 'Medium', 'Low'], n_points, p=[0.1, 0.3, 0.6]),
        'evacuation_difficulty': np.random.choice(['Hard', 'Medium', 'Easy'], n_points, p=[0.1, 0.3, 0.6])
    })
    return df


# Загружаем данные
df = load_data()

# Фильтры
with st.sidebar:
    st.markdown("### ⚙️ Фильтры")

    regions = sorted(df['region'].dropna().unique())
    region_selection = st.multiselect("Регионы:", regions, default=regions[:min(3, len(regions))])

    season_selection = []
    if 'season' in df.columns:
        seasons = sorted(df['season'].dropna().unique())
        season_selection = st.multiselect("Сезоны:", seasons, default=seasons)

    terrain_selection = []
    if 'terrain_type' in df.columns:
        terrains = sorted(df['terrain_type'].dropna().unique())
        terrain_selection = st.multiselect("Тип местности:", terrains, default=terrains)

    risk_selection = []
    if 'risk_level' in df.columns:
        risks = sorted(df['risk_level'].dropna().unique())
        risk_selection = st.multiselect("Уровень риска:", risks, default=risks)

    time_range = st.slider("Время суток (часы):", 0, 23, (6, 18))

    if st.button("🔄 Сбросить фильтры"):
        st.rerun()

# Применение фильтров
filtered_df = df.copy()
if region_selection:
    filtered_df = filtered[filtered_df['region'].isin(region_selection)]

if season_selection:
    filtered_df = filtered_df[filtered_df['season'].isin(season_selection)]

if terrain_selection:
    filtered_df = filtered_df[filtered_df['terrain_type'].isin(terrain_selection)]

if risk_selection:
    filtered_df = filtered_df[filtered_df['risk_level'].isin(risk_selection)]


# Ключевые метрики
st.markdown("<h2 class='section-header'>📈 Ключевые метрики</h2>", unsafe_allow_html=True)
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(f"<div class='metric-card'><h3>🎯 Треков</h3><h2>{filtered_df['track_id'].nunique()}</h2></div>", unsafe_allow_html=True)

with col2:
    avg_steps = filtered_df['step_frequency'].mean() if 'step_frequency' in filtered_df else 0
    st.markdown(f"<div class='metric-card'><h3>👣 Частота шагов</h3><h2>{avg_steps:.1f}</h2></div>", unsafe_allow_html=True)

with col3:
    pop_region = filtered_df['region'].mode()[0] if not filtered_df.empty else '-'
    st.markdown(f"<div class='metric-card'><h3>🏆 Популярный регион</h3><h2>{pop_region}</h2></div>", unsafe_allow_html=True)

with col4:
    if 'risk_level' in filtered_df:
        high_risk = (filtered_df['risk_level'] == 'High').sum()
        risk_pct = (high_risk / len(filtered_df) * 100) if len(filtered_df) > 0 else 0
        st.markdown(f"<div class='metric-card'><h3>⚠️ Высокий риск</h3><h2>{risk_pct:.1f}%</h2></div>", unsafe_allow_html=True)


# Анализ трендов
st.markdown("<h2 class='section-header'>📊 Аналитика трендов</h2>", unsafe_allow_html=True)
tab1, tab2, tab3 = st.tabs(["📈 Сезонные", "🏞️ Местность", "🌡️ Погода"])

with tab1:
    if 'season' in filtered_df and 'step_frequency' in filtered_df:
        fig = px.bar(filtered_df.groupby('season')['step_frequency'].mean().reset_index(),
                     x='season', y='step_frequency', title='Частота шагов по сезонам')
        st.plotly_chart(fig, use_container_width=True)

with tab2:
    if 'terrain_type' in filtered_df:
        fig = px.pie(filtered_df['terrain_type'].value_counts(), names=None, values=None, title='Распределение местности')
        st.plotly_chart(fig, use_container_width=True)

with tab3:
    if 'temperature' in filtered_df and 'step_frequency' in filtered_df:
        fig = px.scatter(filtered_df, x='temperature', y='step_frequency', trendline='ols', title='Шаги vs Температура')
        st.plotly_chart(fig, use_container_width=True)


# Карта
st.markdown("<h2 class='section-header'>🗺️ Интерактивная карта</h2>", unsafe_allow_html=True)
center_lat = filtered_df['lat'].mean()
center_lon = filtered_df['lon'].mean()
m = folium.Map(location=[center_lat, center_lon], zoom_start=8)

colors = {'High': 'red', 'Medium': 'orange', 'Low': 'green'}
for _, row in filtered_df.iterrows():
    color = colors.get(row.get('risk_level', 'Low'), 'blue')
    popup = f"Трек: {row['track_id']}<br>Риск: {row['risk_level']}"
    folium.CircleMarker([row['lat'], row['lon']], radius=5, color=color, fill=True, popup=popup).add_to(m)

st_folium(m, width=1200, height=500)


# Экспорт
st.markdown("---")
if st.button("📥 Экспортировать данные"):
    csv = filtered_df.to_csv(index=False, encoding='utf-8-sig')
    st.download_button("Скачать CSV", data=csv, file_name=f"export_{datetime.now():%Y%m%d}.csv", mime="text/csv")


st.markdown("<div style='text-align:center; color:#6B7280;'>📊 Аналитическая система | Обновлено в реальном времени</div>", unsafe_allow_html=True)