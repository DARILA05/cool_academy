# Модуль Б: Анализ и визуализация данных


## Установка

```bash
pip install -r requirements.txt


# Запуск дашборда
streamlit run app.py