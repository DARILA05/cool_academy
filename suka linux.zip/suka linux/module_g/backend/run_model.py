import os
import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier

# Создаем директорию если её нет
os.makedirs('models', exist_ok=True)

# Создаем фиктивную модель для демонстрации
print("Creating dummy model for demonstration...")

# Создаем фиктивные данные
np.random.seed(42)
X_dummy = np.random.rand(1000, 10)
y_dummy = np.random.randint(0, 2, 1000)

# Обучаем простую модель
model = RandomForestClassifier(n_estimators=50, random_state=42)
model.fit(X_dummy, y_dummy)

# Сохраняем модель
model_path = 'models/best_model.pkl'
joblib.dump(model, model_path)
print(f"Model saved to {model_path}")

# Создаем фиктивный прогноз
dates = pd.date_range(start='2024-06-01', end='2024-12-31', freq='D')
regions = ['moscow', 'spb', 'kazan', 'sochi', 'ekb']

forecast_data = []
for region in regions:
    for date in dates:
        forecast_data.append({
            'region': region,
            'date': date.strftime('%Y-%m-%d'),
            'forecast': np.random.uniform(1, 5)
        })

forecast_df = pd.DataFrame(forecast_data)
forecast_path = 'models/forecast.csv'
forecast_df.to_csv(forecast_path, index=False)
print(f"Forecast saved to {forecast_path}")
print(f"Model ready for API")