from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel
from typing import List, Optional
import pandas as pd
import joblib
import numpy as np
import datetime
import os
from fastapi.middleware.cors import CORSMiddleware

# Загружаем переменные окружения
from dotenv import load_dotenv
load_dotenv()

# Пути из .env
MODEL_PATH = os.getenv("MODEL_PATH", "models/best_model.pkl")
FORECAST_PATH = os.getenv("FORECAST_PATH", "models/forecast.csv")

app = FastAPI(title="Трек-Риски API", description="API для оценки туристических рисков и прогнозов моделей")

# Разрешаем CORS для фронтенда
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # В продакшене заменить на конкретные домены
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class RiskRequest(BaseModel):
    lat: float
    lon: float
    date: str

class RoutePoints(BaseModel):
    points: List[List[float]]
    date: Optional[str] = None

# Глобальные переменные
model = None
forecast_df = None


@app.on_event("startup")
def load_model():
    global model, forecast_df
    try:
        model = joblib.load(MODEL_PATH)
        print(f"✅ Модель загружена: {MODEL_PATH}")
        if hasattr(model, 'feature_names_in_'):
            print(f"📊 Признаки модели: {list(model.feature_names_in_)}")
    except Exception as e:
        print(f"⚠️ Не удалось загрузить модель: {e}")
        print("🔧 Создаём фиктивную модель...")
        from sklearn.ensemble import RandomForestClassifier
        X_dummy = np.random.rand(100, 5)
        y_dummy = np.random.randint(0, 2, 100)
        model = RandomForestClassifier(n_estimators=10, random_state=42)
        model.fit(X_dummy, y_dummy)

    try:
        forecast_df = pd.read_csv(FORECAST_PATH, encoding='utf-8')
        print(f"✅ Прогноз загружен: {FORECAST_PATH}")
    except Exception as e:
        print(f"⚠️ Не удалось загрузить прогноз: {e}")
        dates = pd.date_range(start='2024-06-01', end='2024-12-31', freq='D')
        regions = ['moscow', 'spb', 'kazan', 'sochi', 'ekb']
        data = [
            {'region': r, 'date': d.strftime('%Y-%m-%d'), 'forecast': np.random.uniform(1, 5)}
            for r in regions for d in dates
        ]
        forecast_df = pd.DataFrame(data)
        os.makedirs('models', exist_ok=True)
        forecast_df.to_csv(FORECAST_PATH, index=False, encoding='utf-8')
        print(f"🔧 Фиктивный прогноз сохранён: {FORECAST_PATH}")


@app.get("/", include_in_schema=False)
def root():
    return {"msg": "API для оценки рисков. Перейдите на /docs для документации."}


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "model_loaded": model is not None,
        "forecast_loaded": forecast_df is not None,
        "timestamp": datetime.datetime.now().isoformat()
    }


@app.post("/predict/risk")
def predict_risk(req: RiskRequest):
    try:
        if model is None:
            raise HTTPException(status_code=503, detail="Модель не загружена")

        date_obj = datetime.datetime.strptime(req.date[:10], "%Y-%m-%d")
        feats = pd.DataFrame([{
            "lat": req.lat,
            "lon": req.lon,
            "elevation": 100.0,
            "temperature": 20.0,
            "step_frequency": 2.0,
            "month": date_obj.month,
            "day_of_week": date_obj.weekday(),
            "is_weekend": 1 if date_obj.weekday() >= 5 else 0
        }])

        if hasattr(model, 'feature_names_in_'):
            for col in model.feature_names_in_:
                if col not in feats.columns:
                    feats[col] = 0

        proba = model.predict_proba(feats)[:, 1][0] if hasattr(model, 'predict_proba') else float(model.predict(feats)[0])
        risk = "High" if proba > 0.5 else "Not High"

        return {
            "risk_level": risk,
            "probability": float(proba),
            "features_used": list(feats.columns)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка предсказания: {str(e)}")


@app.get("/predict/fire_danger")
def predict_fire(region_id: str, date_from: str, date_to: str):
    try:
        if forecast_df is None:
            raise HTTPException(status_code=503, detail="Прогноз не загружен")

        df_filtered = forecast_df[
            (forecast_df['region'] == region_id) &
            (forecast_df['date'] >= date_from) &
            (forecast_df['date'] <= date_to)
        ]

        return df_filtered.to_dict(orient='records')
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка прогноза: {str(e)}")


@app.get("/route_analysis")
def route_analysis(points: str, date: Optional[str] = None):
    try:
        import ast
        if model is None:
            raise HTTPException(status_code=503, detail="Модель не загружена")

        pts = ast.literal_eval(points)
        if not pts or not isinstance(pts, list):
            raise HTTPException(status_code=400, detail="Неверный формат точек")

        if date is None:
            date = datetime.datetime.now().strftime("%Y-%m-%d")

        date_obj = datetime.datetime.strptime(date[:10], "%Y-%m-%d")
        feats = pd.DataFrame(pts, columns=['lat', 'lon'])
        feats['elevation'] = 100.0
        feats['temperature'] = 20.0
        feats['step_frequency'] = 2.0
        feats['month'] = date_obj.month
        feats['day_of_week'] = date_obj.weekday()
        feats['is_weekend'] = 1 if date_obj.weekday() >= 5 else 0

        if hasattr(model, 'feature_names_in_'):
            for col in model.feature_names_in_:
                if col not in feats.columns:
                    feats[col] = 0

        proba = model.predict_proba(feats)[:, 1] if hasattr(model, 'predict_proba') else model.predict(feats)
        risk_levels = np.where(proba > 0.5, 'High', 'Not High')
        high_risk_count = int((risk_levels == 'High').sum())
        total_points = len(risk_levels)
        evacuation = 'Hard' if high_risk_count > total_points // 2 else 'Easy'

        return {
            "per_point": risk_levels.tolist(),
            "probabilities": [float(p) for p in proba],
            "evacuation": evacuation,
            "high_risk_count": high_risk_count,
            "total_points": total_points
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка анализа маршрута: {str(e)}")