# 1. Перейти в папку проекта
cd /путь/к/module_g

# 2. Установить зависимости (если ещё не установлены)
pip install -r backend/requirements.txt
pip install -r frontend/requirements.txt

# 3. Запустить бэкенд (в одном терминале)
uvicorn backend.main:app --host 0.0.0.0 --port 8000

# 4. В другом терминале — запустить фронтенд
streamlit run frontend/app.py