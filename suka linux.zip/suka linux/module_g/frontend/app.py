import streamlit as st
import requests
import folium
from streamlit_folium import st_folium
import pandas as pd
import datetime
import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:8000")

st.set_page_config(page_title="Анализ риска маршрута", page_icon="🗺️", layout="wide")
st.title("🗺️ Анализ риска туристического маршрута")
st.markdown("Загрузите маршрут в формате CSV или используйте тестовые данные")

with st.sidebar:
    st.header("Настройки")
    backend_url = st.text_input("URL бэкенда", value=BACKEND_URL)
    st.session_state['backend_url'] = backend_url

    st.header("Инструкция")
    st.markdown("""
    1. Загрузите CSV с колонками `lat`, `lon`
    2. Выберите дату
    3. Нажмите «Проанализировать»
    
    **Формат CSV:**
    ```
    lat,lon
    55.75,37.61
    55.76,37.62
    ```
    """)

    if st.button("Загрузить пример"):
        example_data = pd.DataFrame({
            'lat': [55.75, 55.751, 55.752, 55.753, 55.754],
            'lon': [37.61, 37.615, 37.62, 37.625, 37.63]
        })
        st.session_state['route_data'] = example_data
        st.success("✅ Пример загружен!")

col1, col2 = st.columns([2, 1])

with col1:
    uploaded_file = st.file_uploader("Загрузите CSV", type=['csv'], help="Только файлы с lat, lon")
    date_route = st.date_input("Дата маршрута", datetime.date.today())

    if uploaded_file is not None:
        try:
            df = pd.read_csv(uploaded_file, encoding='utf-8')
            if 'latitude' in df.columns: df = df.rename(columns={'latitude': 'lat'})
            if 'longitude' in df.columns: df = df.rename(columns={'longitude': 'lon'})
            if 'LAT' in df.columns: df = df.rename(columns={'LAT': 'lat'})
            if 'LON' in df.columns: df = df.rename(columns={'LON': 'lon'})
            if 'lat' not in df or 'lon' not in df:
                st.error("❌ Файл должен содержать 'lat' и 'lon'")
                df = pd.DataFrame({'lat': [55.75], 'lon': [37.61]})
        except Exception as e:
            st.error(f"❌ Ошибка: {e}")
            df = pd.DataFrame({'lat': [55.75], 'lon': [37.61]})
    elif 'route_data' in st.session_state:
        df = st.session_state['route_data']
    else:
        df = pd.DataFrame({'lat': [55.75], 'lon': [37.61]})

    st.subheader("Маршрут")
    st.dataframe(df.head(10), use_container_width=True)
    if not df.empty: st.map(df)

with col2:
    st.subheader("Анализ")
    if st.button("🚀 Проанализировать", type="primary", use_container_width=True):
        if df.empty:
            st.warning("Загрузите маршрут")
        else:
            with st.spinner("Анализ..."):
                try:
                    backend_url = st.session_state.get('backend_url', BACKEND_URL)
                    response = requests.get(
                        f"{backend_url}/route_analysis",
                        params={
                            "points": str(df[['lat', 'lon']].values.tolist()),
                            "date": str(date_route)
                        },
                        timeout=30
                    )
                    if response.status_code == 200:
                        res = response.json()
                        st.success("✅ Готово!")
                        st.metric("Всего точек", res['total_points'])
                        st.metric("Высокий риск", res['high_risk_count'])
                        st.metric("Эвакуация", res['evacuation'])

                        analysis_df = pd.DataFrame({
                            'Точка': range(1, len(df) + 1),
                            'Широта': df['lat'],
                            'Долгота': df['lon'],
                            'Риск': res['per_point'],
                            'Вероятность': [f"{p:.1%}" for p in res['probabilities']]
                        })
                        st.dataframe(analysis_df, use_container_width=True)

                        m = folium.Map(location=[df['lat'].mean(), df['lon'].mean()], zoom_start=12)
                        for i, row in df.iterrows():
                            color = 'red' if res['per_point'][i] == 'High' else 'green'
                            popup = f"Точка {i+1}<br>Риск: {res['per_point'][i]}<br>Вероятность: {res['probabilities'][i]:.1%}"
                            folium.CircleMarker([row['lat'], row['lon']], radius=8, color=color, fill=True, popup=popup).add_to(m)
                        st_folium(m, width=700, height=400)

                        if res['evacuation'] == 'Hard':
                            st.warning("⚠️ Высокая сложность эвакуации. Рекомендуется дополнительное снаряжение.")
                        else:
                            st.info("✅ Эвакуация простая.")

                    else:
                        st.error(f"❌ Ошибка: {response.status_code}")
                except Exception as e:
                    st.error(f"❌ Ошибка: {e}")

with st.expander("Проверка подключения"):
    if st.button("Проверить бэкенд"):
        try:
            url = st.session_state.get('backend_url', BACKEND_URL)
            resp = requests.get(f"{url}/health", timeout=5)
            st.success(f"✅ Доступен: {resp.json()}")
        except Exception as e:
            st.error(f"❌ Недоступен: {e}")