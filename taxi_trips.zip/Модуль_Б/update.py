def update_data(window):
    """
    Функция каждую минуту обновляет данные
    """
    print("Обновление данных...")
    window.after(60000, update_data, window)