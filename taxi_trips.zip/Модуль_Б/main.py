import tkinter as tk
from tkinter import messagebox
import sys
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from database import test_connection, get_station_load_percentage, get_station_capacity, get_top_stations, get_avg_passenger_count, get_stations_without_infrastructure
from update import update_data
from user_roles import check_user_role



def close_program(window):
    """
    Функция закрывает программу при нажатии на кнопку "Закрыть программу"
    """
    window.quit()
    window.destroy()


def clear_results(frame_canvas, frame_results):
    """
    Функция очищает все выводы и графики
    """
    for widget in frame_results.winfo_children():
        if isinstance(widget, tk.Label):
            widget.config(text="")
        elif isinstance(widget, tk.Frame):
            for child in widget.winfo_children():
                if isinstance(child, tk.Label):
                    child.config(text="")

    for widget in frame_canvas.winfo_children():
        widget.destroy()




# Вывод результатов

# Загруженность станций
def display_station_load_percentage(frame_canvas, frame_results):
    """
    Функция проводит анализ и выводит результат в текстовом и визуальном виде
    """
    clear_results(frame_canvas, frame_results) # Очищает предыдущий результат

    start_time = entry_start_time.get()
    end_time = entry_end_time.get()
    data = get_station_load_percentage("taxi_trips.db", start_time, end_time)
    
    if data is None or len(data) == 0: # Если нет данных
        label_station_load.config(text="Нет данных для отображения.")
    else:
        # Вывод станций
        result = "\n".join([f"Координаты: ({row[0]}, {row[1]}) — {row[2]:.2f}%" for row in data])
        label_station_load.config(text=f"Загруженность станций:\n{result}")
        
        percentages = [row[2] for row in data]
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(range(len(percentages)), percentages, color='skyblue', edgecolor='black')
        ax.set_xlabel("Станции")
        ax.set_ylabel("Загруженность (%)")
        ax.set_title("Загруженность станций")

        # Выводит результат
        canvas = FigureCanvasTkAgg(fig, frame_canvas)
        canvas.get_tk_widget().grid(row=1, column=0, pady=20)
        canvas.draw()


# Реальная пропускная способность станций
def display_station_capacity(frame_canvas, frame_results):
    """
    Функция проводит анализ и выводит результат в текстовом и визуальном виде
    """
    clear_results(frame_canvas, frame_results) # Очищает предыдущий результат

    start_time = entry_start_time.get()
    end_time = entry_end_time.get()
    data = get_station_capacity("taxi_trips.db", start_time, end_time)

    if data is None or len(data) == 0: # Если нет данных
        label_station_capacity.config(text="Нет данных для отображения.")
    else:
        # Вывод станций
        result = "\n".join([f"Координаты: ({row[0]}, {row[1]}) — {row[2]} поездок" for row in data])
        label_station_capacity.config(text=f"Пропускная способность:\n{result}")
        
        capacities = [row[2] for row in data]
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(range(len(capacities)), capacities, color='lightgreen', edgecolor='black')
        ax.set_xlabel("Станции")
        ax.set_ylabel("Количество поездок")
        ax.set_title("Пропускная способность станций")
        
        # Выводит результат
        canvas = FigureCanvasTkAgg(fig, frame_canvas)
        canvas.get_tk_widget().grid(row=1, column=0, pady=20)
        canvas.draw()


# Топ загруженных станций
def display_top_stations(frame_canvas, frame_results):
    """
    Функция проводит анализ и выводит результат в текстовом и визуальном виде
    """
    clear_results(frame_canvas, frame_results) # Очищает предыдущий результат

    start_time = entry_start_time.get()
    end_time = entry_end_time.get()
    data = get_top_stations("taxi_trips.db", start_time, end_time)

    if data is None or len(data) == 0: # Если нет данных
        label_top_stations.config(text="Нет данных для отображения.")
    else:
        # Вывод станций
        result = "\n".join([f"Координаты: ({row[0]}, {row[1]}) — {row[2]} поездок" for row in data])
        label_top_stations.config(text=f"Топ загруженных станций:\n{result}")
        
        station_counts = [row[2] for row in data]
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(range(len(station_counts)), station_counts, color='salmon', edgecolor='black')
        ax.set_xlabel("Станции")
        ax.set_ylabel("Количество поездок")
        ax.set_title("Топ загруженных станций")
        
        # Выводит результат
        canvas = FigureCanvasTkAgg(fig, frame_canvas)
        canvas.get_tk_widget().grid(row=1, column=0, pady=20)
        canvas.draw()


# Среднее количество пассажиров на станциях
def display_avg_passenger_count(frame_canvas, frame_results):
    """
    Функция проводит анализ и выводит результат в текстовом и визуальном виде
    """
    clear_results(frame_canvas, frame_results) # Очищает предыдущий результат

    start_time = entry_start_time.get()
    end_time = entry_end_time.get()
    data = get_avg_passenger_count("taxi_trips.db", start_time, end_time)

    if data is None or len(data) == 0: # Если нет данных
        label_avg_passenger_count.config(text="Нет данных для отображения.")
    else:
        # Вывод станций
        result = "\n".join([f"Координаты: ({row[0]}, {row[1]}) — {row[2]:.2f} пассажиров" for row in data])
        label_avg_passenger_count.config(text=f"Среднее количество пассажиров:\n{result}")
        
        longitudes = [row[0] for row in data]
        passenger_counts = [row[2] for row in data]
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(longitudes, passenger_counts, label='Среднее количество пассажиров', color='blue', marker='o')
        ax.set_xlabel("Станции")
        ax.set_ylabel("Среднее количество пассажиров")
        ax.set_title("Среднее количество пассажиров на станциях")
        
        # Выводит результат
        canvas = FigureCanvasTkAgg(fig, frame_canvas)
        canvas.get_tk_widget().grid(row=1, column=0, pady=20)
        canvas.draw()


# Количество станций без инфраструктуры для маломобильных граждан
def display_stations_without_infrastructure(frame_canvas, frame_results):
    """
    Функция проводит анализ и выводит результат в текстовом и визуальном виде
    """
    clear_results(frame_canvas, frame_results) # Очищает предыдущий результат

    start_time = entry_start_time.get()
    end_time = entry_end_time.get()
    data = get_stations_without_infrastructure("taxi_trips.db", start_time, end_time)

    if data is None or len(data) == 0: # Если нет данных
        label_stations_without_infrastructure.config(text="Нет данных для отображения.")
    else:
        # Вывод станций
        result = "\n".join([f"Координаты: ({row[0]}, {row[1]}) — {row[2]} станций" for row in data])
        label_stations_without_infrastructure.config(text=f"Станции без инфраструктуры:\n{result}")
        
        stations_without_infrastructure = [row[2] for row in data]
        
        # Визуализация
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(range(len(stations_without_infrastructure)), stations_without_infrastructure, color='purple', edgecolor='black')
        ax.set_xlabel("Станции")
        ax.set_ylabel("Количество станций без инфраструктуры")
        ax.set_title("Станции без инфраструктуры для маломобильных граждан")
        
        # Выводит результат
        canvas = FigureCanvasTkAgg(fig, frame_canvas)
        canvas.get_tk_widget().grid(row=1, column=0, pady=20)
        canvas.draw()



# Запуск основного приложения после успешной авторизации
def start_main_app():
    global entry_start_time, entry_end_time, label_station_load, label_station_capacity, label_top_stations, label_avg_passenger_count, label_stations_without_infrastructure
    
    """
    Создаёт окно с заданными параметрами
    """
    window = tk.Tk()
    window.title("Аналитическая система")
    window.attributes("-fullscreen", True)

    """
    Настраивает область экрана (верхнее и нижнее)
    """
    window.grid_rowconfigure(0, weight=1)
    window.grid_rowconfigure(1, weight=1)
    window.grid_columnconfigure(0, weight=1)
    window.grid_columnconfigure(1, weight=1)
    
    update_data(window) # Запускает обновление данных
    
    """
    Создаёт виджет с полями ввода временного интервала с настройкой расположения
    """
    frame_input = tk.Frame(window)
    frame_input.grid(row=0, column=0, sticky="nw")

    """
    Создаёт виджет с кнопками с настройкой расположения
    """
    frame_buttons = tk.Frame(window)
    frame_buttons.grid(row=0, column=1, sticky="ne")

    """
    Создаёт виджет с выводом результатов в текстовом виде с настройкой расположения
    """
    frame_results = tk.Frame(window)
    frame_results.grid(row=1, column=1, sticky="se")

    """
    Создаёт виджет с выводом результатов в визуальном виде с настройкой расположения
    """
    frame_canvas = tk.Frame(window)
    frame_canvas.grid(row=1, column=0, sticky="sw")


    """
    Создаёт поля ввода временного интервала
    """
    tk.Label(frame_input, text="Начало периода (YYYY-MM-DDTHH:MM:SS.000):", font=("Arial", 12)).pack(anchor='nw', padx=10, pady=5)
    entry_start_time = tk.Entry(frame_input, width=30, font=("Arial", 12))
    entry_start_time.pack(anchor='nw', padx=10, pady=5)

    tk.Label(frame_input, text="Конец периода (YYYY-MM-DDTHH:MM:SS.000):", font=("Arial", 12)).pack(anchor='nw', padx=10, pady=5)
    entry_end_time = tk.Entry(frame_input, width=30, font=("Arial", 12))
    entry_end_time.pack(anchor='nw', padx=10, pady=5)


    """
    Создаёт кнопки (фильтры)
    """
    buttons_data = [
        ("Загруженность станций", display_station_load_percentage),
        ("Пропускная способность", display_station_capacity),
        ("Топ станций", display_top_stations),
        ("Среднее количество пассажиров", display_avg_passenger_count),
        ("Станции без инфраструктуры", display_stations_without_infrastructure),
    ] # Хранит список кнопок

    for text, cmd in buttons_data: # Перебирает кнопки
        btn = tk.Button(frame_buttons, text=text, command=lambda c=cmd, fc=frame_canvas, fr=frame_results: c(fc, fr), font=("Arial", 12), bg='#e1e1e1', fg='black')
        btn.pack(anchor='ne', padx=10, pady=5, fill='x')


    """
    Создаёт отдельную кнопку для закрытия программы
    """
    btn_close = tk.Button(frame_buttons, text="Закрыть программу", command=lambda: close_program(window), font=("Arial", 12), bg="black", fg="white")
    btn_close.pack(anchor='ne', padx=10, pady=5, fill='x')

    """
    Создаёт метки результатов (текстовый вид)
    """
    results_frame = tk.Frame(frame_results)
    results_frame.pack(side='right', anchor='se', fill='both', expand=True, padx=10, pady=10)

    labels = [
        "station_load", "station_capacity", "top_stations",
        "avg_passenger_count", "stations_without_infrastructure"
    ]
    
    for label in labels:
        lbl = tk.Label(results_frame, text="", font=("Arial", 12), justify='left', anchor='se')
        lbl.pack(anchor='se', pady=2)

    label_station_load, label_station_capacity, label_top_stations, \
    label_avg_passenger_count, label_stations_without_infrastructure = results_frame.winfo_children()

    """
    Создаёт метки результатов (визуальный вид)
    """
    canvas_frame = tk.Frame(frame_canvas)
    canvas_frame.pack(side='bottom', anchor='sw', fill='both', expand=True, padx=10, pady=10)

    window.mainloop()


# Запуск авторизации
def start_login_app():
    """
    Создаёт окно с заданными параметрами
    """
    window = tk.Tk()
    window.title("Авторизация")
    window.resizable(False, False) # Запрещает изменять размер окна

    tk.Label(window, text="Введите пароль:", font=("Arial", 12)).pack(pady=5)

    password_entry = tk.Entry(window, show="*", font=("Arial", 12))
    password_entry.pack(pady=5)

    btn_check_role = tk.Button(window, text="Проверить роль", command=lambda: check_user_role(password_entry, window, start_main_app), font=("Arial", 12))
    btn_check_role.pack(pady=20)

    window.mainloop()



# Проверка на подключение к БД
if __name__ == "__main__":
    db_path = "taxi_trips.db"
    if test_connection(db_path):
        messagebox.showinfo("Подключение", "Подключение к базе данных успешно!")
        start_login_app()
    else:
        messagebox.showerror("Ошибка", "Не удалось подключиться к базе данных")
        sys.exit()