import sqlite3
import os



def connect_to_db(db_path):
    """
    Функция устанавливает соединение с БД
    """
    try:
        conn = sqlite3.connect(db_path)
        return conn
    except sqlite3.Error as e:
        print(f"Ошибка подключения к базе данных: {e}")
        return None


def execute_query(conn, query, params=()):
    """
    Функция обрабатывает SQL-запрос и возвращает результат
    """
    try:
        cursor = conn.cursor()
        cursor.execute(query, params)
        result = cursor.fetchall()
        return result
    except sqlite3.Error as e:
        print(f"Ошибка выполнения запроса: {e}")
        return None


# Проводим проверку на работоспособность
def test_connection(db_path):
    """
    Функция пытается вызвать подключение к БД и выводит список доступных таблиц
    """
    if not os.path.exists(db_path):
        print("База данных не существует.")
        return False
    
    conn = connect_to_db(db_path)
    if conn:
        query = "SELECT name FROM sqlite_master WHERE type='table';"
        tables = execute_query(conn, query)
        if tables:
            print("Таблицы в базе данных:", tables)
            return True
        else:
            print("Нет таблиц в базе данных")
            return False
    return False




# Запросы для вычисления (фильтры)

# Запрос на вычисление загруженности станций
def get_station_load_percentage(db_path, start_time, end_time):
    query = """
        WITH station_counts AS (
            SELECT 
                pickup_longitude, 
                pickup_latitude, 
                COUNT(*) AS station_count
            FROM taxi_trips
            WHERE lpep_pickup_datetime BETWEEN ? AND ?
            GROUP BY pickup_longitude, pickup_latitude
        ),
        max_station_count AS (
            SELECT MAX(station_count) AS max_count
            FROM station_counts
        )
        SELECT 
            sc.pickup_longitude, 
            sc.pickup_latitude, 
            (sc.station_count * 100.0 / ms.max_count) AS station_load_percentage
        FROM station_counts sc, max_station_count ms;
    """
    conn = connect_to_db(db_path)
    result = execute_query(conn, query, (start_time, end_time))
    conn.close()
    return result


# Запрос на вычисление реальной пропускной способности
def get_station_capacity(db_path, start_time, end_time):
    query = """
        SELECT 
            pickup_longitude, 
            pickup_latitude, 
            COUNT(*) AS station_capacity
        FROM taxi_trips
        WHERE lpep_pickup_datetime BETWEEN ? AND ?
        GROUP BY pickup_longitude, pickup_latitude;
    """
    conn = connect_to_db(db_path)
    result = execute_query(conn, query, (start_time, end_time))
    conn.close()
    return result


# Запрос на вычисление топ загруженных станций
def get_top_stations(db_path, start_time, end_time):
    query = """
        SELECT 
            pickup_longitude, 
            pickup_latitude, 
            COUNT(*) AS station_count
        FROM taxi_trips
        WHERE lpep_pickup_datetime BETWEEN ? AND ?
        GROUP BY pickup_longitude, pickup_latitude
        ORDER BY station_count DESC
        LIMIT 10;
    """
    conn = connect_to_db(db_path)
    result = execute_query(conn, query, (start_time, end_time))
    conn.close()
    return result


# Запрос на вычисление средней количества пассажиров на станциях
def get_avg_passenger_count(db_path, start_time, end_time):
    query = """
        SELECT 
            pickup_longitude, 
            pickup_latitude, 
            AVG(passenger_count) AS avg_passenger_count
        FROM taxi_trips
        WHERE lpep_pickup_datetime BETWEEN ? AND ?
        GROUP BY pickup_longitude, pickup_latitude;
    """
    conn = connect_to_db(db_path)
    result = execute_query(conn, query, (start_time, end_time))
    conn.close()
    return result


# Запрос на вычисление количества станций без инфраструктуры для маломобильных граждан
def get_stations_without_infrastructure(db_path, start_time, end_time):
    query = """
        SELECT 
            pickup_longitude, 
            pickup_latitude, 
            COUNT(*) AS stations_without_infrastructure
        FROM taxi_trips
        WHERE lpep_pickup_datetime BETWEEN ? AND ?
        AND store_and_fwd_flag = 'N'
        GROUP BY pickup_longitude, pickup_latitude;
    """
    conn = connect_to_db(db_path)
    result = execute_query(conn, query, (start_time, end_time))
    conn.close()
    return result