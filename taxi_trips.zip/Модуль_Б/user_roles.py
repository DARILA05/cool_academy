from tkinter import messagebox



def check_user_role(password_entry, window, start_main_app):
    """
    Функция проверяет роль пользователя
    """
    password = password_entry.get()
    
    if password == "admin":
        messagebox.showinfo("Роль пользователя", "Вы вошли в систему!")
        window.destroy()
        start_main_app()
    else:
        messagebox.showerror("Ошибка", "Неверный пароль! Вы не администратор.")
        window.quit()