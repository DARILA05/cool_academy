import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import requests



# Функция для получения оценки удобства поездки на выбранный период и кластер
def get_comfort():
    try:
        url = 'http://localhost:8080/predict/comfort'
        data = {
            'trip_distance': float(entry_distance.get()),
            'trip_duration': float(entry_duration.get()),
            'period': combo_period.get(),
            'cluster': combo_cluster.get()
        }

        if data["period"] and data["cluster"]:
            response = requests.post(url, json=data)
            if response.status_code == 200:
                result = response.json()
                label_result.config(text=f'Оценка для периода \"{data["period"]}\" и кластера \"{data["cluster"]}\":\n{result["grade"]}')
            else:
                label_result.config(text='Ошибка запроса к API')
        else:
            label_result.config(text='Пожалуйста, выберите период и кластер!')
    except Exception as e:
        label_result.config(text=f'Ошибка:\n{e}')


# Функция для получения прогноза загруженности на выбранный период и кластер
def get_congestion():
    try:
        url = 'http://localhost:8080/predict/congestion'
        data = {
            'pickup_longitude': float(entry_longitude.get()),
            'pickup_latitude': float(entry_latitude.get()),
            'period': combo_period.get(),
            'cluster': combo_cluster.get()
        }

        if data["period"] and data["cluster"]:
            response = requests.post(url, json=data)
            if response.status_code == 200:
                result = response.json()
                label_result.config(text=f'Прогноз загруженности для периода \"{data["period"]}\" и кластера \"{data["cluster"]}\":\n{result["predicted_congestion"]}')
            else:
                label_result.config(text='Ошибка запроса к API')
        else:
            label_result.config(text='Пожалуйста, выберите период и кластер!')
    except Exception as e:
        label_result.config(text=f'Ошибка:\n{e}')


# Функция для отображения справки
def show_help():
    help_text = (
        '1. Введите данные для оценки удобства поездки (расстояние и продолжительность).\n'
        '2. Введите данные для прогноза загруженности (координаты).\n'
        '3. Выберите кластер (например, "Оптимальные").\n'
        '4. Выберите период времени (например, "Следующий час").\n'
        '5. Нажмите кнопку для получения прогноза.\n'
        '6. Результаты будут отображены ниже.\n'
        '7. Для справки, нажмите кнопку "Справка".'
    )
    messagebox.showinfo('Справка', help_text)


def start_main_app():
    global entry_longitude, entry_latitude, combo_cluster, combo_period, label_result, entry_distance, entry_duration

    # Создание основного окна
    root = tk.Tk()
    root.resizable(False, False)
    root.title('Прогнозирование характеристик перевозок')

    # Метки и поля для ввода данных
    label_distance = tk.Label(root, text='Расстояние поездки (км):', font=("Arial", 12), justify='center')
    label_distance.pack()
    entry_distance = tk.Entry(root, font=("Arial", 12), justify='center')
    entry_distance.pack(fill='x', pady=[0, 10])

    label_duration = tk.Label(root, text='Продолжительность поездки (минуты):', font=("Arial", 12), justify='center')
    label_duration.pack()
    entry_duration = tk.Entry(root, font=("Arial", 12), justify='center')
    entry_duration.pack(fill='x', pady=[0, 10])

    label_longitude = tk.Label(root, text='Долгота точки посадки:', font=("Arial", 12), justify='center')
    label_longitude.pack()
    entry_longitude = tk.Entry(root, font=("Arial", 12), justify='center')
    entry_longitude.pack(fill='x', pady=[0, 10])

    label_latitude = tk.Label(root, text='Широта точки посадки:', font=("Arial", 12), justify='center')
    label_latitude.pack()
    entry_latitude = tk.Entry(root, font=("Arial", 12), justify='center')
    entry_latitude.pack(fill='x', pady=[0, 10])

    # Выбор кластера
    label_cluster = tk.Label(root, text='Выберите кластер:', font=("Arial", 12), justify='center')
    label_cluster.pack()
    combo_cluster = ttk.Combobox(root, values=["Оптимальные", "Нежелательные", "Нежелательные совсем"], font=("Arial", 12), justify='center')
    combo_cluster.pack(fill='x', pady=[0, 10])

    # Выбор периода времени
    label_period = tk.Label(root, text='Выберите период времени:', font=("Arial", 12), justify='center')
    label_period.pack()
    combo_period = ttk.Combobox(root, values=["Следующий час", "Завтра", "Следующие 3 часа", "Неделя"], font=("Arial", 12), justify='center')
    combo_period.pack(fill='x', pady=[0, 20])

    # Кнопки для получения прогнозов
    button_comfort = tk.Button(root, text='Получить оценку удобства поездки', command=get_comfort, font=("Arial", 12))
    button_comfort.pack(fill='x', pady=5)

    button_congestion = tk.Button(root, text='Получить прогноз загруженности', command=get_congestion, font=("Arial", 12))
    button_congestion.pack(fill='x', pady=5)

    # Метка для отображения результатов
    label_result = tk.Label(root, text='Результаты появятся здесь.', font=("Arial", 12), justify='center')
    label_result.pack(pady=35)

    # Кнопка для справки
    button_help = tk.Button(root, text='Справка', command=show_help, fg="white", background="black", font=("Arial", 12))
    button_help.pack(fill='x')

    # Запуск приложения
    root.mainloop()



if __name__ == "__main__":
    start_main_app()