from fastapi import FastAPI, HTTPException
import uvicorn
import joblib
import pandas as pd
from pydantic import BaseModel



# Загрузка моделей
try:
    best_model = joblib.load("best_model.pkl")
except Exception as e:
    print(f"Ошибка при загрузке модели\"best_model.pkl\": {e}")
    best_model = None
try:
    linear_model = joblib.load("Linear_Regression.pkl")
    rf_model = joblib.load("Random_Forest.pkl")
    svr_model = joblib.load("SVR.pkl")
except Exception as e:
    print(f"Ошибка при загрузке регрессионных моделей: {e}")
    linear_model, rf_model, svr_model = None, None, None



# Определение схемы входных данных
class TripFeatures(BaseModel):
    trip_distance: float
    trip_duration: float

class CongestionFeatures(BaseModel):
    pickup_longitude: float
    pickup_latitude: float

# Маппинг кластеров на текстовые описания
CLUSTER_MAPPING = {
    0: "Оптимальный",
    1: "Нежелательный",
    2: "Нежелательный совсем"
}



# Инициализация FastAPI
app = FastAPI(title="Taxi Trips", description="Анализируйте поездки и станции в реальном времени!")


# Эндпоинт для оценки удобства поездки
@app.post("/predict/comfort", summary="Оценка удобства поездки", tags=["Использование итоговой модели классификации"])
def predict_comfort(features: TripFeatures):
    if best_model is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    try:
        data = pd.DataFrame([features.dict()])
        cluster = int(best_model.predict(data)[0])  # Преобразование в int
        cluster_description = CLUSTER_MAPPING.get(cluster, "Неизвестный кластер")
        return {"grade": cluster_description}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {e}")

# Эндпоинт для прогноза загруженности
@app.post("/predict/congestion", summary="Прогноз загруженности", tags=["Использование итоговой модели классификации"])
def predict_congestion(features: CongestionFeatures):
    if None in (linear_model, rf_model, svr_model):
        raise HTTPException(status_code=500, detail="Модель не загружена!")
    try:
        data = pd.DataFrame([features.dict()])
        lr_pred = linear_model.predict(data)[0]
        rf_pred = rf_model.predict(data)[0]
        svr_pred = svr_model.predict(data)[0]
        avg_pred = (lr_pred + rf_pred + svr_pred) / 3
        return {"predicted_congestion": avg_pred}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка сервера: {e}")



# Запуск сервера
if __name__ == "__main__":
    uvicorn.run("main:app", host="localhost", port=8080, reload=True)